<?php
use App\Query as DB;

class UserModel
{
}
?>