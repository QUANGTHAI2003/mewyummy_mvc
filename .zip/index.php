<?php
  use App\App;
  session_start();
  require_once 'global.php';
  $app = new App();
?>