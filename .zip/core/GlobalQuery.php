<?php

    namespace App\Core;
    class GlobalQuery {
        public $db;
        function __construct() {
            // $this->db = new Database();
        }
    }
