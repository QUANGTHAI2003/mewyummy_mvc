<?php
use App\Query as DB;

class CartModel
{
}
?>